import torch.nn as nn
from .t2t_vit import T2t_vit_t_14
from .Transformer import Transformer
from .Transformer import token_Transformer
from .Decoder import Decoder
from torch.autograd import Variable
import numpy as np
from torch.distributions import Normal, Independent, kl
import torch
import matplotlib.pyplot as plt

def b2g(feature,B,G):
    out = torch.chunk(feature, B, dim=0)
    return out

def g2b(feature, b,g):
    out = torch.cat([torch.mean(feat, keepdim=True, dim=0) for feat in torch.chunk(feature, g, dim=0)], dim=0)
    return out

class Encoder_xy(nn.Module):
    def __init__(self, input_channels, channels, latent_size):
        super(Encoder_xy, self).__init__()
        self.contracting_path = nn.ModuleList()
        self.input_channels = input_channels
        self.relu = nn.ReLU(inplace=True)
        self.layer1 = nn.Conv2d(input_channels, channels, kernel_size=4, stride=2, padding=1)
        self.bn1 = nn.BatchNorm2d(channels)

        self.layer2 = nn.Conv2d(channels, 2*channels, kernel_size=4, stride=2, padding=1)
        self.bn2 = nn.BatchNorm2d(channels * 2)

        self.layer3 = nn.Conv2d(2*channels, 4*channels, kernel_size=4, stride=2, padding=1)
        self.bn3 = nn.BatchNorm2d(channels * 4)

        self.layer4 = nn.Conv2d(4*channels, 8*channels, kernel_size=4, stride=2, padding=1)
        self.bn4 = nn.BatchNorm2d(channels * 8)

        self.layer5 = nn.Conv2d(8*channels, 8*channels, kernel_size=4, stride=2, padding=1)
        self.bn5 = nn.BatchNorm2d(channels * 8)

        self.channel = channels

        self.fc1 = nn.Linear(channels * 32 * 7 * 7, latent_size)
        self.fc2 = nn.Linear(channels * 32 * 7 * 7, latent_size)

        self.leakyrelu = nn.LeakyReLU()

    def forward(self, x):

        output = self.leakyrelu(self.bn1(self.layer1(x)))
        output = self.leakyrelu(self.bn2(self.layer2(output)))
        output = self.leakyrelu(self.bn3(self.layer3(output)))
        output = self.leakyrelu(self.bn4(self.layer4(output)))
        output = self.leakyrelu(self.bn5(self.layer5(output)))
        output = output.view(-1, self.channel * 32 * 7 * 7)

        mu = self.fc1(output)
        logvar = self.fc2(output)
        dist = Independent(Normal(loc=mu, scale=torch.exp(logvar)), 1)

        return dist, mu, logvar

class Encoder_x(nn.Module):
    def __init__(self, input_channels, channels, latent_size):
        super(Encoder_x, self).__init__()
        self.contracting_path = nn.ModuleList()
        self.input_channels = input_channels
        self.relu = nn.ReLU(inplace=True)
        self.layer1 = nn.Conv2d(input_channels, channels, kernel_size=4, stride=2, padding=1)
        self.bn1 = nn.BatchNorm2d(channels)

        self.layer2 = nn.Conv2d(channels, 2*channels, kernel_size=4, stride=2, padding=1)
        self.bn2 = nn.BatchNorm2d(channels * 2)

        self.layer3 = nn.Conv2d(2*channels, 4*channels, kernel_size=4, stride=2, padding=1)
        self.bn3 = nn.BatchNorm2d(channels * 4)

        self.layer4 = nn.Conv2d(4*channels, 8*channels, kernel_size=4, stride=2, padding=1)
        self.bn4 = nn.BatchNorm2d(channels * 8)

        self.layer5 = nn.Conv2d(8*channels, 8*channels, kernel_size=4, stride=2, padding=1)
        self.bn5 = nn.BatchNorm2d(channels * 8)
        self.channel = channels

        self.fc1 = nn.Linear(channels * 24 * 7 * 7, latent_size)
        self.fc2 = nn.Linear(channels * 24 * 7 * 7, latent_size)

        self.leakyrelu = nn.LeakyReLU()

    def forward(self, input):
        output = self.leakyrelu(self.bn1(self.layer1(input)))
        output = self.leakyrelu(self.bn2(self.layer2(output)))
        output = self.leakyrelu(self.bn3(self.layer3(output)))
        output = self.leakyrelu(self.bn4(self.layer4(output)))
        output = self.leakyrelu(self.bn5(self.layer5(output)))
        output = output.view(-1, self.channel * 24 * 7 * 7)

        mu = self.fc1(output)
        logvar = self.fc2(output)
        dist = Independent(Normal(loc=mu, scale=torch.exp(logvar)), 1)

        return dist, mu, logvar

class ImageDepthNet(nn.Module):
    def __init__(self, args):
        super(ImageDepthNet, self).__init__()

        self.rgb_backbone = T2t_vit_t_14(pretrained=True, args=args)

        self.transformer = Transformer(embed_dim=384, depth=4, num_heads=6, mlp_ratio=3.)

        self.token_trans = token_Transformer(embed_dim=384, depth=4, num_heads=6, mlp_ratio=3.)
        self.decoder = Decoder(embed_dim=384, token_dim=64, depth=2, img_size=args.img_size)
        
        self.group_size = args.group_size

        self.fc1 = nn.Linear(8 * 11 * 11, 8)
        self.fc2 = nn.Linear(8 * 11 * 11, 8)
        self.fc3 = nn.Linear(3, 1)
        self.xy_encoder = Encoder_xy(5, 4, 3)
        self.x_encoder = Encoder_x(5, 3, 3)
        self.spatial_axes = [1, 2]

        self.mode = args.mode

    def reparametrize(self, mu, logvar):
        std = logvar.mul(0.5).exp_()
        eps = torch.cuda.FloatTensor(std.size()).normal_()
        eps = Variable(eps)
        return eps.mul(std).add_(mu)

    def kl_divergence(self, posterior_latent_space, prior_latent_space):
        kl_div = kl.kl_divergence(posterior_latent_space, prior_latent_space)
        return kl_div

    def tile(self, a, dim, n_tile):
        """
        This function is taken form PyTorch forum and mimics the behavior of tf.tile.
        Source: https://discuss.pytorch.org/t/how-to-tile-a-tensor/13853/3
        """
        init_dim = a.size(dim)
        repeat_idx = [1] * a.dim()
        repeat_idx[dim] = n_tile
        a = a.repeat(*(repeat_idx))
        order_index = torch.LongTensor(np.concatenate([init_dim * np.arange(n_tile) + i for i in range(init_dim)])).cuda()
        return torch.index_select(a, dim, order_index)

    def forward(self, image_Input, label):
        saliency_fea_1_16 = []
        fea_1_16 = []
        saliency_tokens = []
        contour_fea_1_16 = []
        contour_tokens = []
        co_tokens = []
        loss_bank_1 = []
        loss_bank_2 = []
        criterion = nn.BCEWithLogitsLoss()
        if self.mode=='test':
            self.group_size = image_Input.shape[0]

        self.batch_size = image_Input.shape[0]//self.group_size

        if self.batch_size == 2:
            _, _, _ = self.rgb_backbone(image_Input)
            prepare = _.view(-1, 14, 14, 64).permute(0, 3, 1, 2)
            upnear = nn.UpsamplingBilinear2d(scale_factor=16)
            prepare = upnear(prepare).mean(dim=1).unsqueeze(1)
            prepare_1 = prepare[0:5, :, :, ]
            prepare_2 = prepare[5:10, :, :, ]
            label_1 = label[0:5, :, :, ]
            label_2 = label[5:10, :, :, ]
            for ii in range(5):
                loss_temp_1 = criterion(prepare_1[ii], label_1[ii])
                loss_temp_2 = criterion(prepare_2[ii], label_2[ii])
                loss_bank_1.append(loss_temp_1)
                loss_bank_2.append(loss_temp_2)
            a = loss_bank_1.index(max(loss_bank_1))
            b = loss_bank_2.index(max(loss_bank_2))
            image_Input[a] = image_Input[a] + image_Input[b + 5]
            image_Input[b + 5] = image_Input[a] - image_Input[b + 5]
            image_Input[a] = image_Input[a] - image_Input[b + 5]
            label[a] = label[a] + label[b + 5]
            label[b + 5] = label[a] - label[b + 5]
            label[a] = label[a] - label[b + 5]
            label[a] = torch.zeros(size=[1, 1, 224, 224])
            label[b + 5] = torch.zeros(size=[1, 1, 224, 224])


            rgb_fea_1_16, rgb_fea_1_8, rgb_fea_1_4 = self.rgb_backbone(image_Input)
            q_repeats = b2g(rgb_fea_1_16, self.batch_size, self.group_size)
            torch.cuda.empty_cache()
        else:
            rgb_fea_1_16, rgb_fea_1_8, rgb_fea_1_4 = self.rgb_backbone(image_Input)
            q_repeats = b2g(rgb_fea_1_16, self.batch_size, self.group_size)


        if self.batch_size == 2:
            z = []
            self.posterior_1, muxy_1, logvarxy_1 = self.xy_encoder(torch.cat((image_Input[0:5, :, :, :], label[0:5, :, :, :]), 1).permute(1, 0, 2, 3))
            self.prior_1, mux_1, logvarx_1 = self.x_encoder(image_Input[0:5, :, :, :].permute(1, 0, 2, 3))
            lattent_loss_1 = torch.mean(self.kl_divergence(self.posterior_1, self.prior_1))
            z_noise_post_1 = self.reparametrize(muxy_1, logvarxy_1)
            z_1 = self.tile(self.fc3(z_noise_post_1), 1, rgb_fea_1_16.shape[self.spatial_axes[0]])
            z_1 = torch.unsqueeze(z_1, 2)
            z_1 = self.tile(z_1, 2, rgb_fea_1_16.shape[self.spatial_axes[1]])
            z.append(z_1)

            self.posterior_2, muxy_2, logvarxy_2 = self.xy_encoder(torch.cat((image_Input[5:, :, :, :], label[5:, :, :, :]), 1).permute(1, 0, 2, 3))
            self.prior_2, mux_2, logvarx_2 = self.x_encoder(image_Input[5:, :, :, :].permute(1, 0, 2, 3))
            lattent_loss_2 = torch.mean(self.kl_divergence(self.posterior_2, self.prior_2))
            z_noise_post_2 = self.reparametrize(muxy_2, logvarxy_2)
            z_2 = self.tile(self.fc3(z_noise_post_2), 1, rgb_fea_1_16.shape[self.spatial_axes[0]])
            z_2 = torch.unsqueeze(z_2, 2)
            z_2 = self.tile(z_2, 2, rgb_fea_1_16.shape[self.spatial_axes[1]])
            z.append(z_2)
            lattent_loss = (lattent_loss_1 + lattent_loss_2) / 4
        else:
            z = []
            self.prior_1, mux_1, logvarx_1 = self.x_encoder(image_Input.permute(1, 0, 2, 3))
            z_noise_post_1 = self.reparametrize(mux_1, logvarx_1)
            z_1 = self.tile(self.fc3(z_noise_post_1), 1, rgb_fea_1_16.shape[self.spatial_axes[0]])
            z_1 = torch.unsqueeze(z_1, 2)
            z_1 = self.tile(z_1, 2, rgb_fea_1_16.shape[self.spatial_axes[1]])
            z.append(z_1)

        aa = 0
        for q in q_repeats:
            qk = q.reshape(1, -1, 384)  # 1*980*384
            w = z[aa]
            wk = w.reshape(1, -1, 384)  # 1*980*384
            aa += 1
            memo, neno, co_token = self.transformer(qk, wk)
            neno = torch.cat([neno, neno, neno, neno, neno], dim=0)
            q = memo.reshape(self.group_size, -1, 384)
            w = neno.reshape(self.group_size, -1, 384)
            # VST Decoder
            mask = self.token_trans(q, w)
            saliency_fea_1_16.append(mask[0])
            fea_1_16.append(mask[1])
            saliency_tokens.append(mask[2])
            contour_fea_1_16.append(mask[3])
            contour_tokens.append(mask[4])
            co_tokens.append(co_token.repeat(self.group_size, 1, 1))

        saliency_fea_1_16 = torch.cat(saliency_fea_1_16, dim=0)
        fea_1_16 = torch.cat(fea_1_16, dim=0)
        saliency_tokens = torch.cat(saliency_tokens, dim=0)
        contour_fea_1_16 = torch.cat(contour_fea_1_16, dim=0)
        contour_tokens = torch.cat(contour_tokens, dim=0)
        co_tokens = torch.cat(co_tokens, dim=0)


        outputs = self.decoder(saliency_fea_1_16, fea_1_16, saliency_tokens, contour_fea_1_16, contour_tokens, rgb_fea_1_8, rgb_fea_1_4,co_tokens)

        if self.batch_size == 2:
            return outputs, lattent_loss
        else:
            return outputs
